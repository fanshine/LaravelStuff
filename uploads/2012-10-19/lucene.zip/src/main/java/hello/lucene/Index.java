package hello.lucene;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

public class Index {

	public void index() throws IOException {

		try {
			String docsDir = "src";
			String indexDir = "target/index";
			Directory directory = FSDirectory.open(new File(indexDir));
			Analyzer analyzer = new StandardAnalyzer(Version.LUCENE_40);
			IndexWriterConfig config = new IndexWriterConfig(Version.LUCENE_40,
					analyzer);
			IndexWriter writer = new IndexWriter(directory, config);
			indexDocs(writer, new File(docsDir));
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private void indexDocs(IndexWriter writer, File path) throws IOException {
		if (path.isDirectory()) {
			File[] files = path.listFiles();
			if (files != null) {
				for (int i = 0; i < files.length; i++) {
					indexDocs(writer, files[i]);
				}
			}
		} else {
			FileReader reader = null;
			try {
				Document doc = new Document();
				doc.add(new StringField("name", path.getName(), Field.Store.YES));
				doc.add(new StringField("path", path.getPath(), Field.Store.YES));
				reader = new FileReader(path);
				doc.add(new TextField("contents", reader));
				System.out.println("adding " + path);
				writer.addDocument(doc);
			} finally {
				if (reader != null) {
					reader.close();
				}
			}
		}
	}
}
